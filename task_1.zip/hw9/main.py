from hello import hello

print(hello('me'))
